# SwordlessMod - GitHub Actions ile JAR oluşturma

Bu proje Minecraft 1.12.2 Forge (14.23.5.2860) için hazırlanmıştır.

## GitHub'ta JAR oluşturma

1. Bu klasörü bir GitHub repository'sine yükle.
2. `.github/workflows/build.yml` dosyası otomatik olarak GitHub Actions'ı çalıştırır.
3. GitHub'da **Actions** sekmesine gir.
4. `Build SwordlessMod` workflow'unu seç.
5. İstersen **Run workflow** ile elle başlatabilirsin.
6. İşlem bitince workflow sayfasının altındaki **Artifacts** bölümünden `SwordlessMod-1.12.2` dosyasını indir.

Oluşacak JAR `build/libs/` klasöründe olur.

## Yerelde build

Java 8 ve Gradle 4.10.3 ile:

    gradle build

Çıktı:

    build/libs/SwordlessMod-1.0.jar
