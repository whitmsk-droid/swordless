# Elmas Katana - Swordless Modu

## Bu ne yapıyor?
- **İsim:** Elmas Katana
- **Hasar:** 15 (normal elden gelen 1 hasara ek olarak 14 modifier eklendi, toplam 15)
- **Dayanıklılık:** Elmas kılıç ile birebir aynı (1561 kullanım)
- **Özel yetenek:** Elinde bu kılıç varken **Y tuşuna** basınca, baktığın yöne doğru
  hızlıca fırlarsın (dash). Tuş `key.swordless.dash` olarak kayıtlı, oyun içinde
  Controls (Kontroller) menüsünden başka bir tuşa da atayabilirsin.

## Nereye koymalıyım?
Bu klasördeki `src` klasörünü, senin var olan **Forge 1.12.2 MDK** projenin
`src` klasörünün üzerine kopyala (üzerine yaz / birleştir). Yani:

```
SeninProjen/
├── build.gradle
├── src/
│   └── main/
│       ├── java/com/swordless/   <-- buraya bu dosyalar gelecek
│       └── resources/assets/swordless/  <-- texture, model, lang buraya
```

Eğer henüz sıfırdan bir Forge 1.12.2 MDK projen yoksa, MinecraftForge'un resmi
sitesinden (files.minecraftforge.net) 1.12.2 için MDK indirip önce onu kurman
lazım (Gradle + JDK 8 gerektirir). Senin mesajlarından PC tarafında projeyi
Binny yürütüyor gibi görünüyor - o zaten kurulumu yapmış olabilir, o zaman
sadece bu `src` klasörünü onun projesine eklemen/gondermen yeterli.

## Texture hakkında not
Attığın görsel 720x786 boyutundaydı, ben onu Minecraft'ın standart item
texture boyutu olan **16x16**'ya indirdim (nearest-neighbor, yani piksel
netliği korunuyor). `elmas_katana.png` dosyası
`assets/swordless/textures/items/` altında.

## ThePowerFull (kılıç değil, özel eşya)
- **Görünüm:** Elde kılıç gibi çapraz değil, düz/palm-style duruyor (`item/generated` modeli)
- **Vuruş hasarı:** 0 (taban 1 el hasarı, -1.0 modifier ile 0'a çekildi)
- **Sağ tık:** Baktığın yeri normal bir TNT gücünde (4.0) patlatır
- **R tuşu** (`key.swordless.slow`): Baktığın oyuncuya güçlü bir yavaşlatma (Yavaşlık VI) verir, 5 saniye sürer
  - Not: Yavaşlatmayı "gerçek maksimuma" (255) çıkarmadım çünkü Minecraft'ta bilinen bir bug var —
    çok yüksek seviyelerde hız çarpanı negatife düşüp oyuncuyu geriye doğru yürütmeye başlıyor.
    Yavaşlık VI, bozuk davranışa girmeden en güçlü kararlı seviye. `PacketSlow.java` içindeki
    `SLOWNESS_AMPLIFIER` değerini değiştirerek istediğin an ayarlayabilirsin (ya da bilerek o "ters yürüme" bug'ını da tetikleyebiliriz).

## Sıradaki eşya
Bir sonraki texture'ı ve özelliğini attığında aynı şekilde:
- yeni bir `Item...` sınıfı (veya gerekirse aynı sisteme entegre ederim)
- hasar/dayanıklılık ayarı
- istenen özel yetenek (yeni tuş, sağ tık efekti, sneak+tık, vs. - ne istersen)
ekleyip aynı projeye dahil ederim.
