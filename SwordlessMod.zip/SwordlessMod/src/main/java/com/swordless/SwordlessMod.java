package com.swordless;

import com.swordless.handler.HurtSoundHandler;
import com.swordless.init.ModItems;
import com.swordless.init.ModSounds;
import com.swordless.network.NetworkHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = SwordlessMod.MODID, name = SwordlessMod.NAME, version = SwordlessMod.VERSION)
public class SwordlessMod
{
    public static final String MODID = "swordless";
    public static final String NAME = "Swordless";
    public static final String VERSION = "1.0";

    @SidedProxy(clientSide = "com.swordless.ClientProxy", serverSide = "com.swordless.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
        ModItems.register();
        ModSounds.register();
        NetworkHandler.registerMessages();
        MinecraftForge.EVENT_BUS.register(new HurtSoundHandler());
        proxy.preInit(event);
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {
        proxy.init(event);
    }
}
