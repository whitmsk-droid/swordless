package com.swordless.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.swordless.SwordlessMod;
import com.swordless.init.ModCreativeTab;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/**
 * Doner Bicagi
 * - Ozel bir yetenegi yok.
 * - Vurus hasari: 15 (taban 1 + 14 modifier).
 * - Dayaniklilik: 500 (net olarak istendi).
 */
public class ItemDonerBicagi extends Item
{
    private static final double EXTRA_ATTACK_DAMAGE = 14.0D; // toplam 15 olsun diye
    private static final int DURABILITY = 500;

    public ItemDonerBicagi()
    {
        this.setRegistryName(SwordlessMod.MODID, "doner_bicagi");
        this.setUnlocalizedName(SwordlessMod.MODID + ".doner_bicagi");
        this.setCreativeTab(ModCreativeTab.SWORDLESS_TAB);
        this.setMaxStackSize(1);
        this.setMaxDamage(DURABILITY);
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack)
    {
        Multimap<String, AttributeModifier> multimap = HashMultimap.create();

        if (slot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", EXTRA_ATTACK_DAMAGE, 0));
        }

        return multimap;
    }
}
