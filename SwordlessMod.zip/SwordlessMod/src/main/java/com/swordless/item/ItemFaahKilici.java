package com.swordless.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.swordless.SwordlessMod;
import com.swordless.init.ModCreativeTab;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/**
 * Faah Kilici
 * - Vurus hasari: 1 (taban el hasari zaten 1 oldugu icin modifier 0 birakildi).
 * - Birine vurdugunda ozel bir ses cikarir (bkz. handler/HurtSoundHandler.java,
 *   ModSounds.FAAH_HIT).
 * - Dayaniklilik: ozellikle belirtilmedigi icin elmas kilic seviyesinde (1561)
 *   varsayildi.
 */
public class ItemFaahKilici extends Item
{
    private static final double EXTRA_ATTACK_DAMAGE = 0.0D; // taban 1 zaten yeterli
    private static final int DURABILITY = 1561; // varsayim - elmas kilic seviyesi

    public ItemFaahKilici()
    {
        this.setRegistryName(SwordlessMod.MODID, "faah_kilici");
        this.setUnlocalizedName(SwordlessMod.MODID + ".faah_kilici");
        this.setCreativeTab(ModCreativeTab.SWORDLESS_TAB);
        this.setMaxStackSize(1);
        this.setMaxDamage(DURABILITY);
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack)
    {
        Multimap<String, AttributeModifier> multimap = HashMultimap.create();

        if (slot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", EXTRA_ATTACK_DAMAGE, 0));
        }

        return multimap;
    }
}
