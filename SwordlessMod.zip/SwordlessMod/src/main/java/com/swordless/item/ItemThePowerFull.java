package com.swordless.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.swordless.SwordlessMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * ThePowerFull
 * - Kilic degil, elde "duz" (item/generated) gorunecek bir esya.
 * - Normal vurus hasari: 0 (taban 1 hasar, -1.0 modifier ile 0'a cekildi;
 *   Minecraft'ta ATTACK_DAMAGE attribute'unun alt siniri 0 oldugu icin
 *   negatife dusmez, guvenle 0'da kalir).
 * - Sag tik: baktigi yeri normal bir TNT gucunde (4.0F) patlatir.
 * - R tusu (bkz ClientProxy / KeyInputHandler / PacketPowerSlow): baktigi
 *   oyuncuya/canliya en guclu yavaslatmayi (Slowness, amplifier 255) verir.
 */
public class ItemThePowerFull extends Item
{
    private static final double ATTACK_DAMAGE_VALUE = -1.0D;

    public static final float EXPLOSION_STRENGTH = 4.0F; // normal TNT gucu
    public static final double RAY_TRACE_RANGE = 100.0D;

    public ItemThePowerFull()
    {
        this.setRegistryName(SwordlessMod.MODID, "thepowerfull");
        this.setUnlocalizedName(SwordlessMod.MODID + ".thepowerfull");
        this.setCreativeTab(com.swordless.init.ModCreativeTab.SWORDLESS_TAB);
        this.setMaxStackSize(1);
        this.setMaxDamage(0);
        this.setRarity(EnumRarity.EPIC);
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack)
    {
        Multimap<String, AttributeModifier> multimap = HashMultimap.create();

        if (slot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", ATTACK_DAMAGE_VALUE, 0));
        }

        return multimap;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand)
    {
        ItemStack stack = player.getHeldItem(hand);

        if (!world.isRemote)
        {
            Vec3d target = getLookTarget(player, RAY_TRACE_RANGE);
            boolean mobGriefing = world.getGameRules().getBoolean("mobGriefing");
            world.newExplosion(player, target.x, target.y, target.z, EXPLOSION_STRENGTH, false, mobGriefing);
        }

        player.swingArm(hand);
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    /**
     * Oyuncunun baktigi yonde, bir bloga carpana kadar (ya da maxRange'e kadar)
     * gidilecek noktayi hesaplar.
     */
    public static Vec3d getLookTarget(EntityPlayer player, double maxRange)
    {
        Vec3d eyePos = player.getPositionEyes(1.0F);
        Vec3d look = player.getLook(1.0F);
        Vec3d endPos = eyePos.add(look.x * maxRange, look.y * maxRange, look.z * maxRange);

        RayTraceResult result = player.world.rayTraceBlocks(eyePos, endPos, false, false, true);

        if (result != null && result.hitVec != null)
        {
            return result.hitVec;
        }

        return endPos;
    }
}
