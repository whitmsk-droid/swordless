package com.swordless.item;

import com.swordless.SwordlessMod;
import com.swordless.init.ModArmorMaterials;
import com.swordless.init.ModCreativeTab;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;

/**
 * Gunes Gozlugu
 * - Normal bir kask (helmet) slotuna takilir.
 * - Kozmetik: koruma vermez, sadece gorunum.
 * - Kafanin tamamini kaplamaz - textures/models/armor/gunes_gozlugu_layer_1.png
 *   sadece goz hizasindaki ince bir seridi boyali (geri kalani seffaf), bu yuzden
 *   oyuncunun kendi kafa/sac skin'i gorunmeye devam eder, sanki gozluk takmis gibi durur.
 */
public class ItemGunesGozlugu extends ItemArmor
{
    public ItemGunesGozlugu()
    {
        super(ModArmorMaterials.SUNGLASSES, 0, EntityEquipmentSlot.HEAD);
        this.setRegistryName(SwordlessMod.MODID, "gunes_gozlugu");
        this.setUnlocalizedName(SwordlessMod.MODID + ".gunes_gozlugu");
        this.setCreativeTab(ModCreativeTab.SWORDLESS_TAB);
        this.setMaxStackSize(1);
    }
}
