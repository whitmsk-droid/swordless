package com.swordless.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.swordless.SwordlessMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

/**
 * Elmas Katana
 * - Normal vurus hasari: 15 (elmas kilicin cok uzerinde, "keskinlik" temasi icin)
 * - Dayanikliligi: elmas kilic ile ayni (Item.ToolMaterial.DIAMOND -> 1561 kullanim)
 * - Ozel yetenek: Y tusuna basinca bakilan yone dogru firlar (dash).
 *   Bu davranis KeyInputHandler + PacketDash uzerinden calisir, bu sinif
 *   sadece hasari ve gorunumu tanimlar.
 */
public class ItemElmasKatana extends ItemSword
{
    // Toplam vurus hasari 15 olsun istiyoruz.
    // Oyuncunun eli zaten 1.0 temel hasar veriyor, bu yuzden modifier = 15 - 1 = 14
    private static final double EXTRA_ATTACK_DAMAGE = 14.0D;
    private static final double ATTACK_SPEED = -2.4D;

    public ItemElmasKatana()
    {
        super(Item.ToolMaterial.DIAMOND);
        this.setRegistryName(SwordlessMod.MODID, "elmas_katana");
        this.setUnlocalizedName(SwordlessMod.MODID + ".elmas_katana");
        this.setCreativeTab(com.swordless.init.ModCreativeTab.SWORDLESS_TAB);
        this.setMaxDamage(Item.ToolMaterial.DIAMOND.getMaxUses()); // elmas kilic ile ayni dayaniklilik
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack)
    {
        Multimap<String, AttributeModifier> multimap = HashMultimap.create();

        if (slot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", EXTRA_ATTACK_DAMAGE, 0));
            multimap.put(SharedMonsterAttributes.ATTACK_SPEED.getName(),
                    new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", ATTACK_SPEED, 0));
        }

        return multimap;
    }
}
