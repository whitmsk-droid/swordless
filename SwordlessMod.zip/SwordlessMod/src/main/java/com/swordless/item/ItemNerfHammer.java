package com.swordless.item;

import com.swordless.SwordlessMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

/**
 * Nerf Hammer
 * - Kullanicinin Blockbench'te modelledigi gercek 3D item (elde caprazlar
 *   arasi kilic pozu degil, kendi geometrisiyle gorunur).
 * - Su an ozel bir yetenegi yok - sap kahverengi, kafa koyu yesil.
 * - Ileride istenirse ozellik eklenir (diger kiliclardaki gibi).
 */
public class ItemNerfHammer extends Item
{
    public ItemNerfHammer()
    {
        this.setRegistryName(SwordlessMod.MODID, "nerf_hammer");
        this.setUnlocalizedName(SwordlessMod.MODID + ".nerf_hammer");
        this.setCreativeTab(com.swordless.init.ModCreativeTab.SWORDLESS_TAB);
        this.setMaxStackSize(1);
    }
}
