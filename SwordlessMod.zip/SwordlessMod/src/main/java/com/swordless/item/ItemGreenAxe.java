package com.swordless.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.swordless.SwordlessMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/**
 * Green Axe
 * - Ozel bir yetenegi yok.
 * - Vurus hasari: 30 (taban 1 el hasarina +29 modifier eklendi).
 * - Dayaniklilik: ozellikle belirtilmedigi icin elmas kilic seviyesinde (1561)
 *   varsayildi - Elmas Katana ile ayni mantik. Farkli istersen kolayca degistiririm.
 */
public class ItemGreenAxe extends Item
{
    private static final double EXTRA_ATTACK_DAMAGE = 29.0D; // toplam 30 olsun diye
    private static final int DURABILITY = 1561; // elmas kilic seviyesi (varsayim)

    public ItemGreenAxe()
    {
        this.setRegistryName(SwordlessMod.MODID, "green_axe");
        this.setUnlocalizedName(SwordlessMod.MODID + ".green_axe");
        this.setCreativeTab(com.swordless.init.ModCreativeTab.SWORDLESS_TAB);
        this.setMaxStackSize(1);
        this.setMaxDamage(DURABILITY);
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack)
    {
        Multimap<String, AttributeModifier> multimap = HashMultimap.create();

        if (slot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", EXTRA_ATTACK_DAMAGE, 0));
        }

        return multimap;
    }

    @Override
    public boolean isDamageable()
    {
        return true;
    }
}
