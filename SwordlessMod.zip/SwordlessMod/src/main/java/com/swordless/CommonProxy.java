package com.swordless;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class CommonProxy
{
    public void preInit(FMLPreInitializationEvent event)
    {
        // Server tarafinda yapilacak ozel bir sey yok
    }

    public void init(FMLInitializationEvent event)
    {
    }
}
