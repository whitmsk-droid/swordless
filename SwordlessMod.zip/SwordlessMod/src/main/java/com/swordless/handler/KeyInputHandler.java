package com.swordless.handler;

import com.swordless.ClientProxy;
import com.swordless.init.ModItems;
import com.swordless.network.NetworkHandler;
import com.swordless.network.PacketDash;
import com.swordless.network.PacketSlow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class KeyInputHandler
{
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event)
    {
        if (event.phase != TickEvent.Phase.END)
        {
            return;
        }

        EntityPlayerSP player = Minecraft.getMinecraft().player;
        if (player == null)
        {
            return;
        }

        // isPressed() tetiklendiginde otomatik sifirlanir, boylece basili tutmak
        // her tick'te tekrar tekrar dash atmaz.
        if (ClientProxy.DASH_KEY.isPressed())
        {
            ItemStack held = player.getHeldItemMainhand();
            if (!held.isEmpty() && held.getItem() == ModItems.ELMAS_KATANA)
            {
                NetworkHandler.INSTANCE.sendToServer(new PacketDash());
            }
        }

        // R tusu - ThePowerFull elindeyken baktigi oyuncuyu yavaslatir
        if (ClientProxy.SLOW_KEY.isPressed())
        {
            ItemStack held = player.getHeldItemMainhand();
            if (!held.isEmpty() && held.getItem() == ModItems.THE_POWERFULL)
            {
                NetworkHandler.INSTANCE.sendToServer(new PacketSlow());
            }
        }
    }
}
