package com.swordless.handler;

import com.swordless.init.ModSounds;
import com.swordless.item.ItemFaahKilici;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Faah Kilici ile birine (mob/oyuncu) basarili bir vurus yapildiginda
 * ozel .ogg sesini caldirir. LivingHurtEvent hem client hem server'da
 * ateslenir, bu yuzden sadece server tarafinda calisip World#playSound
 * ile tum yakindaki oyunculara otomatik yayiyoruz (cift ses cikmasin diye).
 */
public class HurtSoundHandler
{
    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event)
    {
        Entity source = event.getSource().getTrueSource();

        if (!(source instanceof EntityPlayer))
        {
            return;
        }

        EntityPlayer attacker = (EntityPlayer) source;
        World world = attacker.world;

        if (world.isRemote)
        {
            return;
        }

        ItemStack held = attacker.getHeldItemMainhand();
        if (!held.isEmpty() && held.getItem() instanceof ItemFaahKilici)
        {
            Entity target = event.getEntityLiving();
            world.playSound(null, target.posX, target.posY, target.posZ,
                    ModSounds.FAAH_HIT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        }
    }
}
