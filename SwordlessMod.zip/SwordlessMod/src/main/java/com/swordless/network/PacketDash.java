package com.swordless.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/**
 * Y tusuna basildiginda client -> server gonderilen bos paket.
 * Server, oyuncuyu baktigi yone dogru firlatir (dash / ileri atilma).
 */
public class PacketDash implements IMessage
{
    public PacketDash() {}

    @Override
    public void fromBytes(ByteBuf buf) {}

    @Override
    public void toBytes(ByteBuf buf) {}

    public static class Handler implements IMessageHandler<PacketDash, IMessage>
    {
        // Firlama gucu - ihtiyaca gore ayarlanabilir
        private static final double DASH_STRENGTH = 1.6D;
        private static final double DASH_UPWARD = 0.15D;

        @Override
        public IMessage onMessage(PacketDash message, MessageContext ctx)
        {
            EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(() -> {
                Vec3d look = player.getLookVec();

                double motionX = look.x * DASH_STRENGTH;
                double motionY = Math.max(player.motionY, look.y * DASH_STRENGTH * 0.5) + DASH_UPWARD;
                double motionZ = look.z * DASH_STRENGTH;

                player.motionX = motionX;
                player.motionY = motionY;
                player.motionZ = motionZ;
                player.velocityChanged = true;

                // Yeni hizi client'a bildir, yoksa client kendi hesabiyla gecersiz kilar
                player.connection.sendPacket(new SPacketEntityVelocity(player));
                player.fallDistance = 0.0F;
            });

            return null;
        }
    }
}
