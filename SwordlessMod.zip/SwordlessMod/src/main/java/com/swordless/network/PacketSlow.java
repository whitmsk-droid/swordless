package com.swordless.network;

import com.swordless.init.ModItems;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/**
 * R tusuna basildiginda client -> server gonderilen bos paket.
 * Server, ThePowerFull elinde ise, oyuncunun baktigi oyuncuya
 * en guclu yavaslatmayi (Yavaslik X) verir.
 */
public class PacketSlow implements IMessage
{
    // Yavaslatma seviyesi: amplifier 5 = "Yavaslik VI".
    // NOT: Bunu daha da yukari cekmek (7+) Minecraft'in bilinen bir quirk'i yuzunden
    // hiz carpanini negatife dusurup oyuncuyu GERI GERI yurutmeye basliyor.
    // 5, "neredeyse hic hareket edemiyor" ile "bozuk davranis yok" arasindaki en guclu deger.
    private static final int SLOWNESS_AMPLIFIER = 5;
    // Sure: 5 saniye (100 tick)
    private static final int SLOWNESS_DURATION_TICKS = 100;
    // Ne kadar uzaga kadar oyuncu arayalim
    private static final double TARGET_RANGE = 100.0D;

    public PacketSlow() {}

    @Override
    public void fromBytes(ByteBuf buf) {}

    @Override
    public void toBytes(ByteBuf buf) {}

    public static class Handler implements IMessageHandler<PacketSlow, IMessage>
    {
        @Override
        public IMessage onMessage(PacketSlow message, MessageContext ctx)
        {
            EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(() -> {

                ItemStack held = player.getHeldItemMainhand();
                if (held.isEmpty() || held.getItem() != ModItems.THE_POWERFULL)
                {
                    return;
                }

                EntityPlayer target = findLookedAtPlayer(player, TARGET_RANGE);
                if (target != null)
                {
                    target.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS,
                            SLOWNESS_DURATION_TICKS, SLOWNESS_AMPLIFIER, false, true));
                }
            });

            return null;
        }

        /**
         * Oyuncunun bakis vektoru uzerinde, belirli bir mesafe icinde en yakin
         * BASKA bir oyuncuyu bulur (kendisi haric).
         */
        private static EntityPlayer findLookedAtPlayer(EntityPlayerMP player, double range)
        {
            Vec3d eyePos = player.getPositionEyes(1.0F);
            Vec3d look = player.getLook(1.0F);
            Vec3d endPos = eyePos.add(look.x * range, look.y * range, look.z * range);

            // Bakis yonunde blok engeli var mi, varsa mesafeyi kisaltalim
            RayTraceResult blockHit = player.world.rayTraceBlocks(eyePos, endPos, false, true, false);
            double maxDist = blockHit != null && blockHit.hitVec != null
                    ? eyePos.distanceTo(blockHit.hitVec)
                    : range;

            EntityPlayer closest = null;
            double closestDist = Double.MAX_VALUE;

            for (EntityPlayer other : player.world.playerEntities)
            {
                if (other == player)
                {
                    continue;
                }

                Vec3d toEntity = other.getPositionVector().add(0, other.height / 2.0, 0).subtract(eyePos);
                double dist = toEntity.length();
                if (dist > maxDist)
                {
                    continue;
                }

                double dot = toEntity.normalize().dotProduct(look);
                // dot ~1.0 tam bakis yonu demek; genis bir tolerans birakiyoruz
                if (dot > 0.97 && dist < closestDist)
                {
                    closest = other;
                    closestDist = dist;
                }
            }

            return closest;
        }
    }
}
