package com.swordless.network;

import com.swordless.SwordlessMod;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler
{
    public static final SimpleNetworkWrapper INSTANCE =
            NetworkRegistry.INSTANCE.newSimpleChannel(SwordlessMod.MODID);

    public static void registerMessages()
    {
        int id = 0;
        INSTANCE.registerMessage(PacketDash.Handler.class, PacketDash.class, id++, Side.SERVER);
        INSTANCE.registerMessage(PacketSlow.Handler.class, PacketSlow.class, id++, Side.SERVER);
    }
}
