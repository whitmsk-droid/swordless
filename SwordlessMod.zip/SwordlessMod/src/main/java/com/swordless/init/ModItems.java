package com.swordless.init;

import com.swordless.SwordlessMod;
import com.swordless.item.ItemElmasKatana;
import com.swordless.item.ItemDonerBicagi;
import com.swordless.item.ItemFaahKilici;
import com.swordless.item.ItemGunesGozlugu;
import com.swordless.item.ItemGreenAxe;
import com.swordless.item.ItemNerfHammer;
import com.swordless.item.ItemThePowerFull;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModItems
{
    public static final Item ELMAS_KATANA = new ItemElmasKatana();
    public static final Item THE_POWERFULL = new ItemThePowerFull();
    public static final Item NERF_HAMMER = new ItemNerfHammer();
    public static final Item GREEN_AXE = new ItemGreenAxe();
    public static final Item FAAH_KILICI = new ItemFaahKilici();
    public static final Item DONER_BICAGI = new ItemDonerBicagi();
    public static final Item GUNES_GOZLUGU = new ItemGunesGozlugu();

    public static void register()
    {
        GameRegistry.register(ELMAS_KATANA);
        GameRegistry.register(THE_POWERFULL);
        GameRegistry.register(NERF_HAMMER);
        GameRegistry.register(GREEN_AXE);
        GameRegistry.register(FAAH_KILICI);
        GameRegistry.register(DONER_BICAGI);
        GameRegistry.register(GUNES_GOZLUGU);
    }
}
