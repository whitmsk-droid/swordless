package com.swordless.init;

import com.swordless.SwordlessMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;

/**
 * Swordless modunun butun esyalarinin (Elmas Katana, ThePowerFull, Nerf Hammer,
 * Green Axe...) toplandigi ozel yaratici mod sekmesi.
 * Sekme ismi (dil dosyasindaki "itemGroup.swordless") uzerinden gorunur.
 */
public class ModCreativeTab extends CreativeTabs
{
    public static final CreativeTabs SWORDLESS_TAB = new ModCreativeTab();

    private ModCreativeTab()
    {
        super(SwordlessMod.MODID);
    }

    @Override
    public ItemStack getTabIconItem()
    {
        // Sekme ikonu - istersen baska bir esyayla degistirebilirsin
        return new ItemStack(ModItems.ELMAS_KATANA);
    }

    @Override
    public boolean hasSearchBar()
    {
        return false;
    }
}
