package com.swordless.init;

import com.swordless.SwordlessMod;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModSounds
{
    public static final SoundEvent FAAH_HIT = createSoundEvent("faah_hit");

    private static SoundEvent createSoundEvent(String name)
    {
        ResourceLocation location = new ResourceLocation(SwordlessMod.MODID, name);
        return new SoundEvent(location).setRegistryName(location);
    }

    public static void register()
    {
        GameRegistry.register(FAAH_HIT);
    }
}
