package com.swordless.init;

import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraftforge.common.util.EnumHelper;

public class ModArmorMaterials
{
    /**
     * Gunes Gozlugu icin: koruma 0 (sadece kozmetik), dayaniklilik dusuk
     * (kirilmasi onemli degil ama sonsuz da olmasin), buyulenebilirlik dusuk.
     * "swordless:gunes_gozlugu" -> textures/models/armor/gunes_gozlugu_layer_1.png
     */
    public static final ItemArmor.ArmorMaterial SUNGLASSES = EnumHelper.addArmorMaterial(
            "SWORDLESS_SUNGLASSES",
            "swordless:gunes_gozlugu",
            50,                     // durability multiplier
            new int[] {0, 0, 0, 0}, // boots, legs, chest, head - koruma yok
            9,                      // enchantability
            SoundEvents.ITEM_ARMOR_EQUIP_LEATHER,
            0.0F                    // toughness
    );
}
