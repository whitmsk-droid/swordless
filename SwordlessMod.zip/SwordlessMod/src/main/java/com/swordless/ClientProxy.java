package com.swordless;

import com.swordless.handler.KeyInputHandler;
import com.swordless.init.ModItems;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.settings.KeyBinding;

public class ClientProxy extends CommonProxy
{
    // Y tusu - kilinci ileri firlatma / dash tusu
    public static final KeyBinding DASH_KEY = new KeyBinding(
            "key.swordless.dash",
            KeyConflictContext.IN_GAME,
            Keyboard.KEY_Y,
            "key.categories.swordless"
    );

    // R tusu - ThePowerFull ile baktigi oyuncuyu yavaslatma
    public static final KeyBinding SLOW_KEY = new KeyBinding(
            "key.swordless.slow",
            KeyConflictContext.IN_GAME,
            Keyboard.KEY_R,
            "key.categories.swordless"
    );

    @Override
    public void preInit(FMLPreInitializationEvent event)
    {
        super.preInit(event);
        ClientRegistry.registerKeyBinding(DASH_KEY);
        ClientRegistry.registerKeyBinding(SLOW_KEY);
        MinecraftForge.EVENT_BUS.register(new KeyInputHandler());
        MinecraftForge.EVENT_BUS.register(new ModelRegisterHandler());
    }

    @Override
    public void init(FMLInitializationEvent event)
    {
        super.init(event);
    }

    @SideOnly(Side.CLIENT)
    public static class ModelRegisterHandler
    {
        @SubscribeEvent
        public void onModelRegister(ModelRegistryEvent event)
        {
            ModelLoader.setCustomModelResourceLocation(ModItems.ELMAS_KATANA, 0,
                    new ModelResourceLocation(ModItems.ELMAS_KATANA.getRegistryName(), "inventory"));
            ModelLoader.setCustomModelResourceLocation(ModItems.THE_POWERFULL, 0,
                    new ModelResourceLocation(ModItems.THE_POWERFULL.getRegistryName(), "inventory"));
            ModelLoader.setCustomModelResourceLocation(ModItems.NERF_HAMMER, 0,
                    new ModelResourceLocation(ModItems.NERF_HAMMER.getRegistryName(), "inventory"));
            ModelLoader.setCustomModelResourceLocation(ModItems.GREEN_AXE, 0,
                    new ModelResourceLocation(ModItems.GREEN_AXE.getRegistryName(), "inventory"));
            ModelLoader.setCustomModelResourceLocation(ModItems.FAAH_KILICI, 0,
                    new ModelResourceLocation(ModItems.FAAH_KILICI.getRegistryName(), "inventory"));
            ModelLoader.setCustomModelResourceLocation(ModItems.DONER_BICAGI, 0,
                    new ModelResourceLocation(ModItems.DONER_BICAGI.getRegistryName(), "inventory"));
            ModelLoader.setCustomModelResourceLocation(ModItems.GUNES_GOZLUGU, 0,
                    new ModelResourceLocation(ModItems.GUNES_GOZLUGU.getRegistryName(), "inventory"));
        }
    }
}
